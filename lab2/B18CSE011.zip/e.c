#include <stdio.h>
#include <stdlib.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <fcntl.h>
#define __USE_GNU
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <wait.h>

int main()
{
    srand(time(NULL)); // seed to get a proper random number

    char **colors = (char **)malloc(7 * sizeof(char *));

    char color0[] = "Violet";
    char color1[] = "Indigo";
    char color2[] = "Blue";
    char color3[] = "Green";
    char color4[] = "Yellow";
    char color5[] = "Orange";
    char color6[] = "Red";

    colors[0] = color0;
    colors[1] = color1;
    colors[2] = color2;
    colors[3] = color3;
    colors[4] = color4;
    colors[5] = color5;
    colors[6] = color6;

    // use the first pipe to read from child 1
    int p11[2];

    int p_check = pipe(p11);
    if (p_check == -1)
    {
        perror("pipe");
        exit(1);
    }

    // use the second pipe to read from child 2
    int p21[2];

    p_check = pipe(p21);
    if (p_check == -1)
    {
        perror("pipe2");
        exit(1);
    }

    signal(SIGCHLD, SIG_IGN); // handling child exit.

    pid_t ch1 = fork();
    if (ch1 == -1)
    {
        perror("fork");
        exit(1);
    }

    else if (ch1 == 0)
    {
        // what the first child needs to do...
        // stdout for this child needs to be the write end
        // of the pipe created for it.

        // close the read end because it will write to this pipe.
        close(p11[0]);

        // close pipes related to second child
        close(p21[1]);
        close(p21[0]);

        // write end of pipe to act for stdout of this process
        int d_check = dup2(p11[1], STDOUT_FILENO);
        if (d_check == -1)
        {
            perror("dup1 child 1");
            exit(1);
        }

        // to be able to set a different seed for proper random number generation
        sleep(3);

        int r_check = execl("player", "player", NULL);
        if (r_check == -1)
        {
            perror("player 1");
            exit(1);
        }
    }

    else
    {
        pid_t ch2 = fork();
        if (ch2 == -1)
        {
            perror("fork2");
            exit(1);
        }

        else if (ch2 == 0)
        {
            // what the second child needs to do...

            // close read end as it will write to it.
            close(p21[0]);

            // close the other child's pipes' descriptors
            close(p11[1]);
            close(p11[0]);

            // set this process to write to write end of the pipe
            int d_check = dup2(p21[1], STDOUT_FILENO);
            if (d_check == -1)
            {
                perror("dup1 child 2");
                exit(1);
            }

            // to be able to set a different seed for proper random number generation
            sleep(1);

            int r_check = execl("player", "player", NULL);
            if (r_check == -1)
            {
                perror("player 2");
                exit(1);
            }
        }

        else
        {
            // what the parent does...

            //close write ends of the pipes from which it reads.
            close(p11[1]);
            close(p21[1]);

            int rfd1 = p11[0]; // parent reads from child 1
            int rfd2 = p21[0]; // parent reads from child 2

            int ch1_score = 0, ch2_score = 0;

            // parent's choice
            int choice = ' ';

            // first child's guess
            char guess1[5];

            // second child's guess
            char guess2[5];

            char response;

            while (1)
            {
                // loop runs till one child wins the game.

                // create parent's choice
                choice = (char)((random() % 7) + '0');
                printf("Parent's choice: %s.\n", colors[choice - '0']);

                // get children's guesses
                int read_check = read(rfd1, guess1, sizeof(guess1));
                if (read_check == -1)
                {
                    perror("read from child 1's pipe");
                    exit(1);
                }

                read_check = read(rfd2, guess2, sizeof(guess2));
                if (read_check == -1)
                {
                    perror("read from child 2's pipe");
                    exit(1);
                }

                printf("Player 1 guessed: %s and scored: %d points.\n", colors[guess1[0] - '0'], abs(choice - guess1[0]));
                printf("Player 2 guessed: %s and scored: %d points.\n", colors[guess2[0] - '0'], abs(choice - guess2[0]));

                // calculate scores of the children after this round.
                ch1_score += abs(choice - guess1[0]);
                ch2_score += abs(choice - guess2[0]);

                if (guess1[0] == choice && guess2[0] == choice)
                {
                    //both guessed correctly, ignore the round.
                    printf("Current Scores-\nP1: %d, P2: %d\n", ch1_score, ch2_score);
                    printf("Both guessed correctly. Moving onto the next round...\n\n");
                }

                else
                {
                    if (guess1[0] == choice)
                    {
                        int k_check = kill(ch1, SIGUSR1); // child 1 won
                        if (k_check == -1)
                        {
                            perror("signalling child 1");
                            exit(1);
                        }

                        k_check = kill(ch2, SIGUSR2); // child 2 lost
                        if (k_check == -1)
                        {
                            perror("signalling child 2");
                            exit(1);
                        }

                        printf("Player 1 has won as only their guess matched.\n");
                        exit(0);
                    }

                    else if (guess2[0] == choice)
                    {
                        int k_check = kill(ch1, SIGUSR2); // child 1 lost
                        if (k_check == -1)
                        {
                            perror("signalling child 1");
                            exit(1);
                        }

                        k_check = kill(ch2, SIGUSR1); // child 2 won
                        if (k_check == -1)
                        {
                            perror("signalling child 2");
                            exit(1);
                        }

                        printf("Player 2 has won as only their guess matched.\n");
                        exit(0);
                    }

                    else if (ch1_score >= 50)
                    {
                        int k_check = kill(ch1, SIGUSR1); // child 1 won
                        if (k_check == -1)
                        {
                            perror("signalling child 1");
                            exit(1);
                        }

                        if (ch2_score >= 50)
                        {
                            k_check = kill(ch2, SIGUSR1); // child 2 won too
                            if (k_check == -1)
                            {
                                perror("signalling child 2");
                                exit(1);
                            }
                            printf("Both the players have won.\n");
                            printf("Current Scores-\nP1: %d, P2: %d\n\n", ch1_score, ch2_score);
                        }
                        else
                        {
                            k_check = kill(ch2, SIGUSR2); // child 2 lost
                            if (k_check == -1)
                            {
                                perror("signalling child 2");
                                exit(1);
                            }
                            printf("Player 1 has won as score >= 50.\n");
                            printf("Current Scores-\nP1: %d, P2: %d\n\n", ch1_score, ch2_score);
                        }
                        exit(0);
                    }

                    else if (ch2_score >= 50)
                    {
                        int k_check = kill(ch2, SIGUSR1); // child 2 won
                        if (k_check == -1)
                        {
                            perror("signalling child 2");
                            exit(1);
                        }
                        if (ch1_score >= 50)
                        {
                            k_check = kill(ch1, SIGUSR1); // child 1 won too
                            if (k_check == -1)
                            {
                                perror("signalling child 1");
                                exit(1);
                            }
                            printf("Both the players have won.\n");
                            printf("Current Scores-\nP1: %d, P2: %d\n\n", ch1_score, ch2_score);
                        }
                        else
                        {
                            k_check = kill(ch1, SIGUSR2); // child 1 lost
                            if (k_check == -1)
                            {
                                perror("signalling child 1");
                                exit(1);
                            }
                            printf("Player 2 has won as score >= 50.\n");
                            printf("Current Scores-\nP1: %d, P2: %d\n\n", ch1_score, ch2_score);
                        }
                        exit(0);
                    }

                    else
                    {
                        // no one has won. onto the next round.
                        printf("Current Scores-\nP1: %d, P2: %d\n", ch1_score, ch2_score);
                        printf("No one has won yet. Moving to the next round...\n\n");
                    }
                }
            }
        }
    }
}