-----------------------------------------------------------
LAB ASSIGNMENT 4
CS330 - Operating Systems
B18CSE011
-----------------------------------------------------------

Compilation and execution:

gcc sch.c -lpthread
./a.out

-----------------------------------------------------------

Note: - The execution of the program is self-explanatory.
It asks the user for the number of workers threads,
the buffer max size and the time slice to be allotted to
each worker thread.

 - The program has been written and tested on Ubuntu 20.04.

-----------------------------------------------------------
